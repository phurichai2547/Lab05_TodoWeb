package sit.int202.todoweb.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.todoweb.models.Task;
import sit.int202.todoweb.models.TaskList;

import java.io.IOException;

@WebServlet(name = "ActionTodoServlet", value = "/action-todo")
public class ActionTodoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action") ; // อ่านค่า parameter ชื่อ "action" จากคำขอ
        String title = request.getParameter("title"); // อ่านค่า parameter ชื่อ "title" จากคำขอ

        if(title != null && action !=null &&
                         (action.equals("toggle") || action.equals("remove") || action.equals("completed"))){
            // ตรวจสอบว่า parameter "title" และ "action" มีค่าและ action เป็น toggle, remove, หรือ completed หรือไม่
            System.out.println("action is "+action); // แสดงค่าของ action ที่ถูกดำเนินการใน console log

            TaskList taskList = new TaskList() ;  // สร้าง instance ของ TaskList เพื่อทำการจัดการกับรายการ Task
            Task task = taskList.find(title) ; // ค้นหา Task ที่มี title ตรงกับที่ระบุ
            switch(action){ // ใช้คำสั่ง switch-case เพื่อแยกการกระทำตามค่าของ action
                case "completed": if(task != null){
                                    task.completed();
                                  }
                                  break ;
                case "remove": if(task != null) {
                                taskList.remove(title);
                               }
                               break ;
                case "toggle": if(task != null){
                                task.toggleStatus();
                               }
                               break ;
            }
            // case "completed":: กรณีที่ action เท่ากับ "completed" คือการทำงานเมื่อผู้ใช้ต้องการทำเครื่องหมายว่า Task ได้เสร็จสิ้นแล้ว
            //if (task != null) { task.completed(); }: เช็คว่า Task ที่ต้องการทำเครื่องหมายว่าเสร็จสิ้นมีอยู่จริงหรือไม่ ถ้ามี ให้เรียกเมทอด completed()
            // ของ Task เพื่อทำการเปลี่ยนสถานะของ Task เป็น "COMPLETED"
            // case "remove":: กรณีที่ action เท่ากับ "remove" คือการทำงานเมื่อผู้ใช้ต้องการลบ Task
            // if (task != null) { taskList.remove(title); }: เช็คว่า Task ที่ต้องการลบมีอยู่จริงหรือไม่ ถ้ามี ให้เรียกเมทอด remove(title)
            // ของ TaskList เพื่อทำการลบ Task ที่ตรงกับชื่อที่ระบุ
            // case "toggle":: กรณีที่ action เท่ากับ "toggle" คือการทำงานเมื่อผู้ใช้ต้องการสลับสถานะของ Task ระหว่าง "NOT_COMPLETED" และ "COMPLETED"
            // if (task != null) { task.toggleStatus(); }: เช็คว่า Task ที่ต้องการสลับสถานะมีอยู่จริงหรือไม่ ถ้ามี ให้เรียกเมทอด toggleStatus()
            // ของ Task เพื่อทำการสลับสถานะของ Task ระหว่าง "NOT_COMPLETED" และ "COMPLETED"
        }

        response.sendRedirect("todo"); // ส่งคำขอ redirect ไปยัง URL "/todo" เพื่อโหลดหน้า Todo List อีกครั้งหลังจากทำการดำเนินการกับ Task เสร็จสิ้น
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
