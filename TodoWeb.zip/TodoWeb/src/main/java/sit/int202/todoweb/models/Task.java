package sit.int202.todoweb.models;

public class Task {
    public enum Status {   //  ประกาศ enum ชื่อ Status เพื่อเก็บสถานะของ Task ซึ่งมีค่าได้แก่ NOT_COMPLETED และ COMPLETED
        NOT_COMPLETED,
        COMPLETED
    }

    private String title; // ประกาศตัวแปร title เพื่อเก็บชื่อของ Task
    private Status status = Status.NOT_COMPLETED; // ประกาศตัวแปร status เพื่อเก็บสถานะของ Task โดยกำหนดให้เริ่มต้นเป็น NOT_COMPLETED

    public Task(String title) {
        this.title = title;
    } // สร้าง constructor สำหรับคลาส Task ที่รับพารามิเตอร์เป็น title เพื่อกำหนดค่าให้กับตัวแปร title

    public String getTitle() {
        return title;
    } // เมทอดเรียกค่า title ของ Task

    public void setTitle(String title) {
        this.title = title;
    } // เมทอดกำหนดค่า title ของ Task

    public Status getStatus() {
        return status;
    } // เมทอดเรียกค่า status ของ Task

    public void setStatus(Status status) {
        this.status = status;
    } // เมทอดกำหนดค่า status ของ Task

    public void completed() {
        this.status = Status.COMPLETED;
    } // เมทอดที่ทำการกำหนด status ของ Task เป็น COMPLETED เมื่อ Task ถูกทำเสร็จ

    public void noCompleted() {
        this.status = Status.NOT_COMPLETED;
    } // เมทอดที่ทำการกำหนด status ของ Task เป็น NOT_COMPLETED เมื่อ Task ยังไม่เสร็จ

    public void toggleStatus() {
        if(this.status==Status.NOT_COMPLETED) {
            this.status = Status.COMPLETED;
        } else {
            this.status = Status.NOT_COMPLETED;
        }
    }  // เมทอดที่ทำการสลับสถานะของ Task ระหว่าง COMPLETED และ NOT_COMPLETED

    @Override
    public String toString() {
        return "Task : "+title+"\nStatus : "+(status==Status.NOT_COMPLETED ?"Not Completed":"Completed");
    }
    // @Override: ประกาศการ override เมทอด toString() เพื่อแสดงข้อมูลของ Task ในรูปแบบ string
    // public String toString() {: เริ่มต้นการประกาศเมทอด toString()
    // return "Task : "+title+"\nStatus : "+(status==Status.NOT_COMPLETED ?"Not Completed":"Completed");:
    // คืนค่า string ที่แสดงชื่อของ Task และสถานะของ Task โดยใช้เงื่อนไข (ternary operator) เพื่อตรวจสอบสถานะของ Task ว่าเสร็จแล้วหรือยัง
    // และแสดงผลลัพธ์ในรูปแบบ string ที่เหมาะสม
}

