package sit.int202.todoweb.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.todoweb.models.TaskList;

import java.io.IOException;

@WebServlet(name = "AddTodoServlet", value = "/add-todo")
public class AddTodoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title"); // อ่านค่า parameter ชื่อ "title" ที่ถูกส่งมาจากแบบฟอร์ม
        if (title != null && title.length()>0) { // ตรวจสอบว่าค่าของ title ไม่เป็น null และมีความยาวมากกว่า 0 คือมีข้อความที่ถูกกรอกเข้ามาในช่องให้กรอกหัวข้อ
            TaskList taskList = new TaskList(); // สร้าง instance ของ TaskList เพื่อทำการจัดการกับรายการ Task
            taskList.addTask(title); // เรียกใช้เมทอด addTask(title) ของ TaskList เพื่อเพิ่ม Task ใหม่โดยใช้ชื่อ (title) ที่ผู้ใช้กรอกเข้ามาในแบบฟอร์ม
        }
        response.sendRedirect("todo"); // ส่งคำขอ redirect ไปยัง URL "/todo" เพื่อโหลดหน้า Todo List อีกครั้งหลังจากทำการเพิ่ม Task เสร็จสิ้น
       // เพื่อให้ผู้ใช้เห็น Task ที่เพิ่มเข้ามาในรายการ Todo List ใหม่ล่าสุด
    }
}
