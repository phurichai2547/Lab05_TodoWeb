package sit.int202.todoweb.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.todoweb.models.TaskList;

import java.io.IOException;

@WebServlet(name = "TodoServlet", value = "/todo")
public class TodoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        TaskList taskList = new TaskList(); // สร้าง instance ของ TaskList เพื่อทำการจัดการกับรายการ Task
        request.setAttribute("tasks", taskList.getTasks()); // กำหนด attribute ชื่อ "tasks" ให้กับ request โดยมีค่าเป็นรายการ Task ทั้งหมดที่ได้จาก TaskList
        RequestDispatcher dispatcher = request.getRequestDispatcher("/todo.jsp"); // สร้าง RequestDispatcher เพื่อส่ง request ไปยังหน้า JSP ที่ชื่อ "/todo.jsp"
        dispatcher.forward(request, response); // ส่ง request และ response ไปยังหน้า JSP ที่เรียกใช้งานเพื่อให้หน้า JSP นั้นแสดงข้อมูลรายการ Task ที่ถูกส่งมาจาก Servlet นี้
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
