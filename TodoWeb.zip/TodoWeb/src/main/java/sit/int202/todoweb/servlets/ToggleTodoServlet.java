package sit.int202.todoweb.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.todoweb.models.Task;
import sit.int202.todoweb.models.TaskList;

import java.io.IOException;

@WebServlet(name = "ToggleTodoServlet", value = "/toggle-todo")
public class ToggleTodoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title"); // อ่านค่า parameter ชื่อ "title" ที่ถูกส่งมาจากคำขอ
        if (title != null && title.length()>0) {  // ตรวจสอบว่าค่าของ title ไม่เป็น null และมีความยาวมากกว่า 0 คือมีข้อความที่ถูกส่งมาในชื่อของ Task ที่ผู้ใช้ต้องการเปลี่ยนสถานะ
            TaskList taskList = new TaskList(); // สร้าง instance ของ TaskList เพื่อทำการจัดการกับรายการ Task
            Task task = taskList.find(title); // ค้นหา Task จาก TaskList ด้วยชื่อ (title) ที่ถูกส่งมา
            if (task != null) {  // ตรวจสอบว่า Task ที่ถูกค้นหามีอยู่จริงหรือไม่ ถ้ามี ให้เรียกเมทอด toggleStatus() ของ Task เพื่อทำการสลับสถานะของ Task
                task.toggleStatus();
            }
        }
        response.sendRedirect("todo"); // ส่งคำขอ redirect ไปยัง URL "/todo" เพื่อโหลดหน้า Todo List อีกครั้งหลังจากทำการเปลี่ยนสถานะของ Task เสร็จสิ้น
        // เพื่อให้ผู้ใช้เห็นการเปลี่ยนแปลงที่เกิดขึ้นในรายการ Todo List ทันที
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
