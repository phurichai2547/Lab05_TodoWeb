package sit.int202.todoweb.models;

import java.util.ArrayList;

public class TaskList {
    private static ArrayList<Task> tasks = new ArrayList<>();
    // ประกาศตัวแปร tasks เป็น ArrayList ที่เก็บ Task โดยมีการกำหนด modifier เป็น private static
    // เพื่อให้สามารถเข้าถึงได้จากทุกที่ในคลาสและสามารถใช้งานได้โดยไม่ต้องสร้าง instance ของ TaskList

    static { // กลุ่มคำสั่งใน static initializer block ที่ทำงานทันทีเมื่อคลาส TaskList ถูกโหลดเข้าสู่หน่วยความจำ เพื่อเพิ่ม Task เริ่มต้นลงใน tasks เมื่อคลาสถูกโหลด
        tasks.add(new Task("Review Java"));
        tasks.add(new Task("Intro Web App"));
    }

    public void addTask(Task newTask) {
        tasks.add(newTask);
    } // เมทอดที่ใช้ในการเพิ่ม Task ใหม่เข้าไปในรายการ tasks

    public void addTask(String title) {
        tasks.add(new Task(title));
    } // เมทอดที่ใช้ในการเพิ่ม Task ใหม่โดยรับชื่อของ Task เป็นพารามิเตอร์

    public static ArrayList<Task> getTasks() {
        return tasks;
    } // เมทอดที่ใช้ในการคืนค่า ArrayList ของ Task ทั้งหมด

    public static void setTasks(ArrayList<Task> tasks) {
        TaskList.tasks = tasks;
    } // เมทอดที่ใช้ในการกำหนด ArrayList ของ Task ทั้งหมด

    public Task find(String title) {
        for (Task task: tasks
             ) {
            if (task.getTitle().equals(title)) {
                return task;
            }
        }
        return null;
    } // เมทอดที่ใช้ในการค้นหา Task จากชื่อ (title) ที่กำหนด และคืนค่า Task ที่พบ หรือ null หากไม่พบ

    public void remove(String title) {
        Task task = this.find(title);
        tasks.remove(task);
    } // เมทอดที่ใช้ในการลบ Task จากรายการ tasks โดยรับชื่อของ Task เป็นพารามิเตอร์

    @Override
    public String toString() {
        StringBuilder task_format = new StringBuilder("--------------------\n");
        task_format.append("List task: \n");
        task_format.append("--------------------\n");
        for (Task task :
                tasks) {
            task_format.append(task.toString()).append('\n');
        }
        return task_format.toString();
    }
}
// @Override: ประกาศการ override เมทอด toString() เพื่อแสดงข้อมูลของ TaskList ในรูปแบบ string
//public String toString() { ... }: เริ่มต้นการประกาศเมทอด toString()
// StringBuilder task_format = new StringBuilder("--------------------\n");: สร้าง StringBuilder เพื่อสร้าง string ที่ใช้ในการแสดงรายการ Task
// task_format.append("List task: \n");: เพิ่มข้อความ "List task: " เข้าไปใน StringBuilder
// for (Task task : tasks) { ... }: วนลูปผ่านรายการ tasks เพื่อเรียกใช้เมทอด toString() ของ Task แต่ละตัวแล้วเพิ่มลงใน StringBuilder
// return task_format.toString();: คืนค่า string ที่ถูกสร้างขึ้นจาก StringBuilder ในรูปแบบของรายการ Task ทั้งหมด
